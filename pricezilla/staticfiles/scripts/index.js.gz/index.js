// var classList = document.getElementById('navscroll').classList;

// var maxWidth576 = window.matchMedia("(max-width: 576px)");
// var windowSize = window.innerWidth;

// function tolu()
// { (windowSize >=576) ? classList.remove('container') : classList.add('container')}

